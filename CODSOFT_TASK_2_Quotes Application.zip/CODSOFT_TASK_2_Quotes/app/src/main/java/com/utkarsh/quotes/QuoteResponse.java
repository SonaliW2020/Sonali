package com.utkarsh.quotes;

public class QuoteResponse {
    private String content;
    private String author;

    public String getContent() {
        return content;
    }

    public String getAuthor() {
        return author;
    }
}
